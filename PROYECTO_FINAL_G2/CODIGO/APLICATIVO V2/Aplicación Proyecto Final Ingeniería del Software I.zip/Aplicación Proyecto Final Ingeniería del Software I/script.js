function handleErrors(fn) {
    try {
      fn();
    } catch (error) {
      console.error('Se produjo un error:', error);
    }
  }
  
  function validateNombreInput() {
    handleErrors(() => {
      const nombreInput = document.getElementById('nombre_paciente');
      const nombre = nombreInput.value;
      const regex = /^[a-zA-Z0-9\s]*$/; // Expresión regular que permite letras, números y espacios
  
      if (!nombre) {
        nombreInput.setCustomValidity('El nombre es obligatorio.');
      } else if (!regex.test(nombre)) {
        nombreInput.setCustomValidity('El nombre no debe contener caracteres especiales.');
      } else {
        nombreInput.setCustomValidity('');
      }
    });
  }
  
  function validateTelefonoInput() {
    handleErrors(() => {
      const telefonoInput = document.getElementById('telefono_paciente');
      const telefono = telefonoInput.value;
      const regex = /^\d{10}$/; // Expresión regular para 10 dígitos numéricos
  
      if (!telefono) {
        telefonoInput.setCustomValidity('El número de teléfono es obligatorio.');
      } else if (!regex.test(telefono)) {
        telefonoInput.setCustomValidity('El número de teléfono debe tener 10 dígitos numéricos.');
      } else {
        telefonoInput.setCustomValidity('');
      }
    });
  }
  
  function validateEmailInput() {
    handleErrors(() => {
      const emailInput = document.getElementById('email_paciente');
      const email = emailInput.value;
      const regex = /^\S+@\S+\.\S+$/; // Expresión regular para validar el formato de correo electrónico
  
      if (!email) {
        emailInput.setCustomValidity('El correo electrónico es obligatorio.');
      } else if (!regex.test(email)) {
        emailInput.setCustomValidity('Ingrese un correo electrónico válido.');
      } else {
        emailInput.setCustomValidity('');
      }
    });
  }
  
  function setFechaMinima() {
    handleErrors(() => {
      const fechaInput = document.getElementById('fecha_vacunacion');
      const fechaMinima = new Date(); // Fecha mínima actual
      fechaInput.min = fechaMinima.toISOString().split('T')[0]; // Establecer la fecha mínima en el formato requerido
    });
  }
  
  function setFechaMaxima() {
    handleErrors(() => {
      const fechaInput = document.getElementById('fecha_vacunacion');
      const fechaMaxima = new Date();
      fechaMaxima.setFullYear(fechaMaxima.getFullYear() + 1); // Añadir 1 año a la fecha actual
      fechaInput.max = fechaMaxima.toISOString().split('T')[0]; // Establecer la fecha máxima en el formato requerido
    });
  }
  
  // Llamar a las funciones para establecer las fechas mínima y máxima
  setFechaMinima();
  setFechaMaxima();
  